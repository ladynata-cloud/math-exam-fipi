/* Offline-only navigation: all lessons stay local; other pages open online. */
(() => {
  'use strict';
  const onlinePage = 'https://mathexam.space/trainers/oge-basics/multiplication-division/arzhenikov-map.html';
  const pagePath = new URL(onlinePage).pathname;
  const archiveName = 'arzhenikov-offline.zip';
  function adapt(link) {
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(href)) return;
    const target = new URL(href, onlinePage);
    if (target.pathname.endsWith('/' + archiveName)) {
      const note = document.createElement('span');
      note.className = 'offline-download-note';
      note.textContent = 'Автономный комплект уже открыт.';
      link.replaceWith(note);
    } else if (target.pathname === pagePath) {
      link.setAttribute('href', target.hash || '#workshop');
    } else {
      link.setAttribute('href', target.href);
    }
  }
  function adaptWithin(root) {
    if (root.matches?.('a[href]')) adapt(root);
    root.querySelectorAll?.('a[href]').forEach(adapt);
  }
  adaptWithin(document);
  new MutationObserver(records => records.forEach(record => {
    if (record.type === 'attributes') adaptWithin(record.target);
    record.addedNodes.forEach(adaptWithin);
  })).observe(document.body, {childList: true, subtree: true, attributes: true, attributeFilter: ['href']});
})();
